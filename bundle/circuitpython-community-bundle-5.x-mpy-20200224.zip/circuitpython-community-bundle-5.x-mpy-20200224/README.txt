See here for more info: https://github.com/adafruit/CircuitPython_Community_Bundle
See VERSIONS.txt for version info.
